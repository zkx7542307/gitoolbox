kset = KBuilder('sample.txt', 2);
dfa = K2dfa(kset);


